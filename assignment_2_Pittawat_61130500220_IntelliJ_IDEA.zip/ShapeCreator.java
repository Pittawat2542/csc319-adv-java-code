public abstract class ShapeCreator {
    public abstract Shape createShape(int size, char pattern);
}
