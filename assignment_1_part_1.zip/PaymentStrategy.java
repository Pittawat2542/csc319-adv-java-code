public interface PaymentStrategy {
    void pay(int total);
}
