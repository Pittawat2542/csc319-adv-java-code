
import java.util.List;
import static java.util.Arrays.asList;

public class SampleData {
   public static final List<Num> nums = asList(new Num(0, "zero"),
                                               new Num(1, "one"),
                                               new Num(2, "two"),
                                               new Num(3, "three"),
                                               new Num(4, "four"),
                                               new Num(5, "five"),
                                               new Num(6, "six"),
                                               new Num(7, "seven"),
                                               new Num(8, "eight"),
                                               new Num(9, "nine"),
                                               new Num(10, "ten"));
}