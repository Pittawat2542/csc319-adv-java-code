
public class Num {
   public int numeric;
   public String word;
   
   public Num(int n, String w) {
      this.numeric = n;
      this.word = w;
   }
}
